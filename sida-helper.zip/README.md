# Sida Helper
this is a extension to help work with https://sida.medu.ir easier and don't waste your time with boring tasks.
it also helps you but some changes in style and accesablity in movements, etc.



### TODO:
initial release:
- [ ] remove `popup.js` and work with click on extension icon.
- [ ] set correct `URL` format for specific page of score lists.
- [ ] show **popup** html content for messages instead of **alerts**.
- [ ] create the **icon**.

Long term:
- [ ] add full feature `popup.html` with shortlinks to the url.

